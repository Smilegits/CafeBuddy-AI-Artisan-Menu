# Architecture Decision Records (ADRs) — CafeBuddy AI

## ADR 1: Build Type Selection
- **Status:** Approved
- **Decision:** Web App with Gemini features (Single container FastAPI backend serving the rich Artisan Harvest mobile-first UI with Gemini 1.5/2.5 Flash API integration).
- **Context:** The application requirements are focused on responsive UI views (Vibe Check, Catalog, Lounge, Kitchen KDS Board) with fast filtering, real-time ticket states, and a conversational AI waiter for table queries.
- **Alternatives Considered:**
  1. *Full Agentic App (Google ADK / Multi-agent framework):* Over-engineered for a restaurant host/menu app, adds cold start latency, higher token costs, and unnecessary complexity.
  2. *Static Site Only (Firebase Hosting without backend):* Unable to cleanly secure Gemini API keys, manage persistent ticket orders, or enforce least-privilege backend guardrails.
- **Consequences:** Low complexity, minimal latency (<1s response), containerized single-service architecture on Cloud Run, easily scales to zero with zero idle cost.

---

## ADR 2: Cloud Hosting — Google Cloud Run
- **Status:** Approved
- **Decision:** Google Cloud Run (min instances: 0, max instances: 2, 512MB RAM, 1 vCPU).
- **Context:** Hard budget limit of $5/month requires scale-to-zero compute.
- **Trade-offs:** First request after idle has ~1-2s container cold-start, but incurs zero charges when idle. Well within the Cloud Run Free Tier (2 million requests/month, 360,000 vCPU-seconds, 180,000 GiB-seconds free).

---

## ADR 3: UI Architecture & Visual System
- **Status:** Approved
- **Decision:** Directly integrate the provided `Artisan Harvest` design system from `stitch_cafebuddy_ai_smart_dining`.
- **Palette:** Deep Espresso (`#2C1E16`), Warm Oat Milk canvas (`#F7F3EE`), Matcha Sage (`#5F7A61`), Spiced Crimson (`#D9381E`) for allergy alerts.
- **Typography:** `Literata` for headings, `Hanken Grotesk` for body/metadata.
- **Pill Philosophy:** Touch-friendly pills (`rounded-full`), instant view switching between Customer Table (`Table #04`) and Barista KDS Screen.

---

## ADR 4: Database Selection — Cloud Firestore (Native Mode)
- **Status:** Approved
- **Decision:** Cloud Firestore in Datastore/Native Mode.
- **Context:** Fits free tier (50,000 document reads, 20,000 writes, 20,000 deletes per day, 1 GiB storage). Excellent document model for active tickets, table states, and simulated lounge profiles.
- **Avoided:** Cloud SQL (PostgreSQL/MySQL), which costs ~$25-$50/month even for small instances and would immediately breach the $5 monthly budget limit.

---

## ADR 5: Gemini Model Selection — Flash-Class
- **Status:** Approved
- **Decision:** `gemini-1.5-flash` / `gemini-2.0-flash` with system prompt guardrails.
- **Context:** Fast inference (<700ms), low token cost ($0.075 / 1M input tokens), handles table assistance, menu pairings, and allergy questions reliably while remaining virtually free for typical cafe traffic.

---

## ADR 6: Hybrid Local-Cloud Repository Architecture
- **Status:** Approved
- **Decision:** Implement a dual-mode repository in `app/database.py` and `app/ai_waiter.py`.
- **Context:** Developers and CI environments may run tests locally without active GCP credentials.
- **Consequences:** The app seamlessly runs anywhere: in Cloud Run with native Cloud Firestore and Vertex AI, and locally in Docker/virtualenv using in-memory threads and fallback intelligence without mock boilerplate.

---

## ADR 7: Scale-to-Zero Cloud Run Deployment Parameters
- **Status:** Approved
- **Decision:** Pin `--min-instances 0`, `--max-instances 2`, `--memory 512Mi`, `--cpu 1`, `--timeout 60s`.
- **Context:** Ensures that when no café guests or baristas are active, instances completely shut down to preserve $0.00 base cost, fitting within the $5.00 monthly cap.

---

## ADR 8: CI/CD Quality Gate & Human Guardrail Teardown
- **Status:** Approved
- **Decision:** Enforce automated unit tests and the 15-case Gemini eval set as a blocking prerequisite in `cloudbuild.yaml` before container deployment. Require explicit human keyboard confirmation (`DELETE`) in `infra/teardown.sh` before irreversible resource removal.
- **Context:** Prevents broken releases from deploying to production and prevents accidental infrastructure deletion.
