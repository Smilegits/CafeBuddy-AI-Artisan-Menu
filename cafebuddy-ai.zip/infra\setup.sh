#!/usr/bin/env bash
# ==============================================================================
# infra/setup.sh — Bootstrap Google Cloud Infrastructure for CafeBuddy AI 2.0
# Idempotent script for project: encouraging-key-468205-j0
# Hard budget limit: $5.00 USD/month | Least-Privilege IAM | Scales to Zero
# ==============================================================================

set -euo pipefail

# Configuration variables
PROJECT_ID="${PROJECT_ID:-encouraging-key-468205-j0}"
REGION="${REGION:-asia-south1}"
SERVICE_ACCOUNT_NAME="cafebuddy-sa"
SERVICE_ACCOUNT_EMAIL="${SERVICE_ACCOUNT_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"
REPOSITORY_NAME="cafebuddy-repo"
SECRET_NAME="cafebuddy-session-secret"
BUDGET_AMOUNT="5.00"

echo "=== [1/7] Setting Active Project & Region ==="
# Set the default Google Cloud project configuration
gcloud config set project "${PROJECT_ID}"

# Set the default Google Cloud compute region configuration
gcloud config set compute/region "${REGION}"


echo "=== [2/7] Enabling Required Google Cloud APIs ==="
# Enable Cloud Run for serverless container execution
gcloud services enable run.googleapis.com

# Enable Firestore for real-time document storage
gcloud services enable firestore.googleapis.com

# Enable Vertex AI for low-cost Gemini Flash intelligence
gcloud services enable aiplatform.googleapis.com

# Enable Artifact Registry for storing production Docker container images
gcloud services enable artifactregistry.googleapis.com

# Enable Secret Manager for least-privilege runtime secret isolation
gcloud services enable secretmanager.googleapis.com

# Enable Cloud Logging for structured event and security logs
gcloud services enable logging.googleapis.com

# Enable Cloud Monitoring for latency and budget tracking
gcloud services enable monitoring.googleapis.com

# Enable Cloud Resource Manager for managing project IAM bindings
gcloud services enable cloudresourcemanager.googleapis.com

# Enable Billing Budgets API for the $5 hard budget alert notifications
gcloud services enable billingbudgets.googleapis.com


echo "=== [3/7] Creating Least-Privilege Service Account ==="
# Check if the dedicated service account already exists to ensure idempotency
if ! gcloud iam service-accounts describe "${SERVICE_ACCOUNT_EMAIL}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
    # Create the dedicated least-privilege service account for CafeBuddy AI
    gcloud iam service-accounts create "${SERVICE_ACCOUNT_NAME}" \
        --project="${PROJECT_ID}" \
        --display-name="CafeBuddy AI Cloud Run Service Account" \
        --description="Least-privilege identity for Cloud Run to access Firestore and Vertex AI"
    echo "Service account created: ${SERVICE_ACCOUNT_EMAIL}"
else
    echo "Service account ${SERVICE_ACCOUNT_EMAIL} already exists. Skipping creation."
fi


echo "=== [4/7] Binding Least-Privilege IAM Roles ==="
# Grant Firestore access for reading/writing menu items, tickets, and lounge state
gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
    --member="serviceAccount:${SERVICE_ACCOUNT_EMAIL}" \
    --role="roles/datastore.user" \
    --condition=None

# Grant Vertex AI user role for invoking Gemini Flash models without API keys
gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
    --member="serviceAccount:${SERVICE_ACCOUNT_EMAIL}" \
    --role="roles/aiplatform.user" \
    --condition=None

# Grant Secret Manager accessor to read isolated runtime configuration
gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
    --member="serviceAccount:${SERVICE_ACCOUNT_EMAIL}" \
    --role="roles/secretmanager.secretAccessor" \
    --condition=None

# Grant Cloud Logging writer to emit structured operational and allergy alerts
gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
    --member="serviceAccount:${SERVICE_ACCOUNT_EMAIL}" \
    --role="roles/logging.logWriter" \
    --condition=None


echo "=== [5/7] Provisioning Storage & Artifact Registry ==="
# Check if the Artifact Registry Docker repository exists before creating
if ! gcloud artifacts repositories describe "${REPOSITORY_NAME}" --location="${REGION}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
    # Create Docker repository in Artifact Registry with standard pricing ($0.10/GB beyond 0.5GB free)
    gcloud artifacts repositories create "${REPOSITORY_NAME}" \
        --project="${PROJECT_ID}" \
        --location="${REGION}" \
        --repository-format=docker \
        --description="Docker container repository for CafeBuddy AI"
    echo "Artifact Registry repository created: ${REPOSITORY_NAME}"
else
    echo "Artifact Registry repository ${REPOSITORY_NAME} already exists. Skipping creation."
fi

# Check if the default Cloud Firestore database exists
if ! gcloud firestore databases describe --project="${PROJECT_ID}" >/dev/null 2>&1; then
    # Create default Firestore database in Native mode within the designated region
    gcloud firestore databases create \
        --project="${PROJECT_ID}" \
        --location="${REGION}" \
        --type=firestore-native
    echo "Cloud Firestore database created in ${REGION} (Native mode)."
else
    echo "Cloud Firestore database already exists. Skipping creation."
fi


echo "=== [6/7] Creating Secret in Secret Manager ==="
# Check if the session secret already exists in Secret Manager
if ! gcloud secrets describe "${SECRET_NAME}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
    # Create secret container in Secret Manager for session encryption
    gcloud secrets create "${SECRET_NAME}" \
        --project="${PROJECT_ID}" \
        --replication-policy="automatic"

    # Generate a cryptographically secure 32-byte secret payload and add as version 1
    openssl rand -hex 32 | tr -d '\n' | gcloud secrets versions add "${SECRET_NAME}" \
        --project="${PROJECT_ID}" \
        --data-file=-
    echo "Secret ${SECRET_NAME} created and populated."
else
    echo "Secret ${SECRET_NAME} already exists. Skipping creation."
fi


echo "=== [7/7] Configuring $5.00 Monthly Budget Alert ==="
# Retrieve the linked Cloud Billing Account ID for the project
BILLING_ACCOUNT=$(gcloud billing projects describe "${PROJECT_ID}" --format="value(billingAccountName)" || true)

if [[ -n "${BILLING_ACCOUNT}" ]]; then
    BILLING_ACCOUNT_ID=$(basename "${BILLING_ACCOUNT}")
    echo "Found linked Billing Account: ${BILLING_ACCOUNT_ID}"
    
    # Check if a budget named 'cafebuddy-5usd-budget' already exists for this billing account
    EXISTING_BUDGET=$(gcloud billing budgets list --billing-account="${BILLING_ACCOUNT_ID}" --filter="displayName:cafebuddy-5usd-budget" --format="value(name)" 2>/dev/null || true)
    
    if [[ -z "${EXISTING_BUDGET}" ]]; then
        # Create budget alert with hard $5.00 limit and thresholds at 50% ($2.50), 90% ($4.50), and 100% ($5.00)
        gcloud billing budgets create \
            --billing-account="${BILLING_ACCOUNT_ID}" \
            --display-name="cafebuddy-5usd-budget" \
            --budget-amount="${BUDGET_AMOUNT}USD" \
            --filter-projects="projects/${PROJECT_ID}" \
            --threshold-rule="percent=0.5,basis=current-spend" \
            --threshold-rule="percent=0.9,basis=current-spend" \
            --threshold-rule="percent=1.0,basis=current-spend"
        echo "Budget alert 'cafebuddy-5usd-budget' created with alerts at $2.50, $4.50, and $5.00."
    else
        echo "Budget alert already exists: ${EXISTING_BUDGET}. Skipping creation."
    fi
else
    echo "WARNING: No linked billing account found or insufficient permissions to query billing. Please set up a $5.00 budget alert in the Google Cloud Console."
fi

echo "=============================================================================="
echo "✅ Infrastructure Bootstrap Complete for Project: ${PROJECT_ID}"
echo "   - Region: ${REGION}"
echo "   - Service Account: ${SERVICE_ACCOUNT_EMAIL}"
echo "   - Artifact Registry: ${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPOSITORY_NAME}"
echo "   - Firestore: Native Mode (${REGION})"
echo "   - Budget: $5.00 USD/month alerts configured"
echo "=============================================================================="
