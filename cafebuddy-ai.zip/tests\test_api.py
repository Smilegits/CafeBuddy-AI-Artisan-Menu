"""
Automated tests for CafeBuddy AI 2.0 API.
Validates:
- Health & static entry points
- 10-Second '3-Tap Vibe Check' (Fuel, Sweetness, Diet, Allergy Guard, Rush Mode)
- Menu Catalog filtering & Express rush exclusion (>7m items excluded)
- Table Ordering & KDS ticket management (Table #04, Elena's Usual, Status transitions)
- Safe Activity-Based Lounge (Table masking, mutual wave match, 10% promo code)
- Table service actions (Water, Staff, Seat change)
"""

import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health_check():
    """Verify health endpoint responds with 200 and healthy status."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "cafebuddy-ai"


def test_index_page_returns_artisan_harvest_ui():
    """Verify root GET renders the single-screen mobile HTML UI."""
    response = client.get("/")
    assert response.status_code == 200
    assert "CafeBuddy AI" in response.text
    assert "10-Sec Vibe Check" in response.text


def test_vibe_check_happy_path():
    """Verify 3-tap vibe check returns top 3 curated recommendations."""
    payload = {
        "fuel": "caffeine",
        "sweetness": 50,
        "diet": "veg",
        "allergies": [],
        "pace": "chilling"
    }
    response = client.post("/api/vibe-check", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert len(data["recommendations"]) == 3
    assert data["express_mode_active"] is False
    # Verify recommendations have high match scores
    for rec in data["recommendations"]:
        assert rec["match_score"] >= 70
        assert rec["item"]["name"] is not None


def test_vibe_check_express_rush_mode_excludes_slow_items():
    """Verify pace='rush' excludes items taking >7 minutes."""
    payload = {
        "fuel": "sweet",
        "sweetness": 100,
        "diet": "veg",
        "allergies": [],
        "pace": "rush"
    }
    response = client.post("/api/vibe-check", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["express_mode_active"] is True
    # French Toast takes 14 mins - must be excluded
    rec_names = [r["item"]["name"] for r in data["recommendations"]]
    assert "Brioche Fig French Toast" not in rec_names
    for rec in data["recommendations"]:
        assert rec["item"]["prep_time_minutes"] <= 7


def test_vibe_check_vegan_diet_filter():
    """Verify vegan diet selection only returns items with vegan tag."""
    payload = {
        "fuel": "savory",
        "sweetness": 0,
        "diet": "vegan",
        "allergies": [],
        "pace": "chilling"
    }
    response = client.post("/api/vibe-check", json=payload)
    assert response.status_code == 200
    data = response.json()
    for rec in data["recommendations"]:
        assert "vegan" in rec["item"]["diet_tags"]


def test_vibe_check_allergy_warning_flag():
    """Verify selecting nuts allergy flags warnings for nut-containing items."""
    payload = {
        "fuel": "caffeine",
        "sweetness": 50,
        "diet": "all",
        "allergies": ["nuts"],
        "pace": "chilling"
    }
    response = client.post("/api/vibe-check", json=payload)
    assert response.status_code == 200
    data = response.json()
    for rec in data["recommendations"]:
        if "nuts" in rec["item"]["allergens"]:
            assert rec["has_allergy_warning"] is True


def test_menu_list_filtering():
    """Verify menu filtering by category and rush pace."""
    # All coffee
    res_coffee = client.get("/api/menu?category=coffee")
    assert res_coffee.status_code == 200
    items = res_coffee.json()
    assert len(items) > 0
    for i in items:
        assert i["category"] == "coffee"

    # Rush mode filter (prep <= 7)
    res_rush = client.get("/api/menu?pace=rush")
    assert res_rush.status_code == 200
    rush_items = res_rush.json()
    for i in rush_items:
        assert i["prep_time_minutes"] <= 7


def test_order_creation_and_kds_sync():
    """Verify customer table order creates an active ticket on KDS board."""
    order_payload = {
        "table_number": "Table #04",
        "guest_name": "Elena S.",
        "zone": "Sunlit Garden Atrium",
        "items": [
            {
                "item_id": "cloud-oat-shaken-espresso",
                "name": "Cloud Oat Shaken Espresso",
                "quantity": 1,
                "modifications": ["50% Honey"],
                "price": 6.50
            }
        ],
        "pace": "rush",
        "tip": 1.50,
        "allergies_noted": ["nuts"],
        "sweetness_noted": "50% Honey"
    }
    response = client.post("/api/orders", json=order_payload)
    assert response.status_code == 200
    ticket = response.json()
    assert ticket["table_number"] == "Table #04"
    assert ticket["is_express"] is True
    assert ticket["has_allergy_alert"] is True
    assert ticket["total"] == 8.00


def test_order_reorder_usual():
    """Verify 1-tap reordering of Elena's usual."""
    response = client.post("/api/orders/reorder-usual?table_number=Table #04")
    assert response.status_code == 200
    ticket = response.json()
    assert ticket["guest_name"] == "Elena S."
    assert len(ticket["items"]) == 2
    assert ticket["total"] == 20.11


def test_empty_order_rejected():
    """Verify submitting an empty order returns 400 Bad Request."""
    response = client.post("/api/orders", json={"table_number": "Table #04", "items": []})
    assert response.status_code == 400


def test_kds_ticket_status_update():
    """Verify barista can transition ticket status to READY and SERVED."""
    res_tickets = client.get("/api/kds/tickets")
    assert res_tickets.status_code == 200
    tickets = res_tickets.json()
    assert len(tickets) > 0
    tkt_id = tickets[0]["ticket_id"]

    # Update to READY
    update_res = client.put(f"/api/kds/tickets/{tkt_id}/status", json={"status": "READY"})
    assert update_res.status_code == 200
    assert update_res.json()["status"] == "READY"


def test_lounge_lobbies_table_masking():
    """Verify lounge lobbies have masked table numbers (Table #??)."""
    response = client.get("/api/lounge")
    assert response.status_code == 200
    lobbies = response.json()
    assert len(lobbies) >= 4
    for lobby in lobbies:
        assert lobby["masked_table"] == "Table #??"


def test_lounge_mutual_wave_reveals_table_and_awards_perk():
    """Verify mutual wave unmasks real table number and unlocks BUDDY10 promo code."""
    wave_payload = {
        "lobby_id": "lobby-dnd-01",
        "guest_table": "Table #04",
        "message": "Down for D&D!"
    }
    response = client.post("/api/lounge/wave", json=wave_payload)
    assert response.status_code == 200
    data = response.json()
    assert data["matched"] is True
    assert data["revealed_table"] == "Table #08"
    assert data["promo_code"] == "BUDDY10"
    assert data["perk_unlocked"] is True


def test_table_service_actions():
    """Verify call staff, water, and seat change requests log successfully."""
    actions = ["water", "staff", "seat_change"]
    for act in actions:
        res = client.post("/api/table/action", json={
            "table_number": "Table #04",
            "action_type": act,
            "details": "Moved to Window"
        })
        assert res.status_code == 200
        assert res.json()["success"] is True
