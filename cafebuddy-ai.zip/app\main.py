"""
Main FastAPI Application for CafeBuddy AI 2.0.
Provides REST APIs for 10-Second Vibe Check, Menu Catalog, KDS Tickets,
Café Buddy Lounge, and the Barista AI Waiter.
"""

import os
from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from app.models import (
    MenuItem,
    VibeCheckRequest,
    VibeCheckResponse,
    VibeCheckRecommendation,
    OrderCreateRequest,
    Ticket,
    TicketStatusUpdateRequest,
    LoungeLobby,
    LoungeWaveRequest,
    LoungeWaveResponse,
    AiWaiterRequest,
    AiWaiterResponse,
    TableActionRequest,
)
from app.database import db
from app.ai_waiter import query_gemini_waiter

app = FastAPI(
    title="CafeBuddy AI 2.0",
    description="Smart Dining Host, Kitchen-Protected Express Filter, and Safe Lounge on Google Cloud",
    version="2.0.0",
)

# CORS middleware for development and deployment
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/", response_class=HTMLResponse)
async def get_index():
    """Serves the primary Artisan Harvest single-screen web app."""
    index_path = os.path.join(static_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return HTMLResponse("<h1>CafeBuddy AI 2.0 Backend Online</h1><p>Static index.html not found.</p>")


@app.get("/health")
async def health_check():
    """Health endpoint for Cloud Run container probes."""
    return {
        "status": "healthy",
        "service": "cafebuddy-ai",
        "timestamp": datetime.utcnow().isoformat(),
        "cloud_project": os.getenv("PROJECT_ID", "encouraging-key-468205-j0"),
    }


# ==============================================================================
# MENU & VIBE CHECK APIS
# ==============================================================================

@app.get("/api/menu", response_model=List[MenuItem])
async def list_menu(
    category: Optional[str] = Query("all", description="all, coffee, bakery, savory"),
    pace: Optional[str] = Query("chilling", description="chilling or rush"),
    diet: Optional[str] = Query("all", description="all, veg, non-veg, vegan"),
    exclude_allergens: Optional[List[str]] = Query(None),
):
    """Retrieves menu items with dynamic Express Mode and dietary filtering."""
    max_prep = 7 if pace == "rush" else None
    return db.get_menu_items(
        category=category,
        max_prep_minutes=max_prep,
        diet=diet,
        exclude_allergens=exclude_allergens,
    )


@app.post("/api/vibe-check", response_model=VibeCheckResponse)
async def process_vibe_check(payload: VibeCheckRequest):
    """
    10-Second '3-Tap Vibe Check':
    - Tap 1: Fuel (Caffeine/Sweet/Meal) & Sweetness
    - Tap 2: Diet (Veg/Non-Veg/Vegan) & Allergy Guard
    - Tap 3: Pace (Chilling vs Rush <=7m)
    Dynamically returns top 3 curated recommendations with explanations.
    """
    all_items = list(db.menu.values())
    filtered_due_to_rush = 0
    scored_items = []

    for item in all_items:
        # Check Express Guard: hide or skip >7 min items if rushed
        if payload.pace == "rush" and item.prep_time_minutes > 7:
            filtered_due_to_rush += 1
            continue

        # Check Diet mismatch
        if payload.diet == "vegan" and "vegan" not in item.diet_tags:
            continue
        if payload.diet == "veg" and ("veg" not in item.diet_tags and "vegan" not in item.diet_tags):
            continue
        if payload.diet == "non-veg" and "non-veg" not in item.diet_tags:
            continue

        # Check Allergens
        has_allergy_conflict = any(alg in item.allergens for alg in payload.allergies)
        if "caffeine_sens" in payload.allergies and item.caffeine:
            has_allergy_conflict = True

        score = 70
        reasons = []

        # Fuel scoring
        if payload.fuel == "caffeine" and item.caffeine:
            score += 20
            reasons.append("Handcrafted caffeine boost")
        elif payload.fuel == "sweet" and ("bakery" in item.category or item.sweetness_default > 0):
            score += 20
            reasons.append("Sweet artisan treat")
        elif payload.fuel == "savory" and item.category == "savory":
            score += 20
            reasons.append("Hearty savory pairing")

        # Sweetness match
        if item.sweetness_default == payload.sweetness:
            score += 10
            reasons.append(f"{payload.sweetness}% sweetness alignment")

        # Prep speed bonus if rushed
        if payload.pace == "rush":
            score += (10 - item.prep_time_minutes)
            reasons.append(f"{item.prep_time_minutes}m rapid prep")

        scored_items.append({
            "item": item,
            "match_score": min(score, 99),
            "reason": " • ".join(reasons) if reasons else "Artisan cafe favorite",
            "is_express": item.prep_time_minutes <= 7,
            "has_allergy_warning": has_allergy_conflict,
        })

    # Sort descending by match score and return top 3
    scored_items.sort(key=lambda x: x["match_score"], reverse=True)
    top_3 = scored_items[:3]

    return VibeCheckResponse(
        recommendations=[VibeCheckRecommendation(**r) for r in top_3],
        express_mode_active=(payload.pace == "rush"),
        filtered_out_due_to_rush=filtered_due_to_rush,
    )


# ==============================================================================
# ORDERS & KITCHEN KDS TICKETS
# ==============================================================================

@app.post("/api/orders", response_model=Ticket)
async def create_order(payload: OrderCreateRequest):
    """Submits order to live Barista KDS board."""
    if not payload.items:
        raise HTTPException(status_code=400, detail="Cannot submit empty order")

    ticket_number = len(db.tickets) + 101
    ticket_id = f"TKT-{ticket_number}"

    subtotal = sum(item.price * item.quantity for item in payload.items)
    total = subtotal + payload.tip

    is_express = (payload.pace == "rush")
    has_allergy = len(payload.allergies_noted) > 0

    ticket = Ticket(
        ticket_id=ticket_id,
        table_number=payload.table_number,
        guest_name=payload.guest_name,
        zone=payload.zone,
        status="IN_PROGRESS",
        is_express=is_express,
        has_allergy_alert=has_allergy,
        allergy_flags=payload.allergies_noted,
        sweetness_level=payload.sweetness_noted,
        items=payload.items,
        subtotal=round(subtotal, 2),
        tip=round(payload.tip, 2),
        total=round(total, 2),
        payment_method="Apple Pay Settled",
        created_at=datetime.utcnow().isoformat(),
        elapsed_time="0m 10s",
    )

    return db.create_ticket(ticket)


@app.post("/api/orders/reorder-usual", response_model=Ticket)
async def reorder_usual(table_number: str = "Table #04"):
    """Simulates 1-tap reordering of Elena's Usual."""
    ticket = Ticket(
        ticket_id=f"TKT-{len(db.tickets) + 101}",
        table_number=table_number,
        guest_name="Elena S.",
        zone="Sunlit Garden Atrium",
        status="IN_PROGRESS",
        is_express=True,
        has_allergy_alert=False,
        allergy_flags=[],
        sweetness_level="50% Honey",
        items=[
            {
                "item_id": "cloud-oat-shaken-espresso",
                "name": "Cloud Oat Shaken Espresso",
                "quantity": 1,
                "modifications": ["Decaf Oat", "50% Honey Sweetness"],
                "price": 6.50,
            },
            {
                "item_id": "avocado-truffle-sourdough",
                "name": "Avocado Truffle Sourdough",
                "quantity": 1,
                "modifications": ["Vegan", "Nut-Free"],
                "price": 10.50,
            },
        ],
        subtotal=17.00,
        tip=3.11,
        total=20.11,
        payment_method="Apple Pay Settled",
        created_at=datetime.utcnow().isoformat(),
        elapsed_time="0m 05s",
    )
    return db.create_ticket(ticket)


@app.get("/api/kds/tickets", response_model=List[Ticket])
async def get_kds_tickets(filter: str = Query("all", description="all, express, allergy")):
    """Retrieves live ticket board for kitchen & barista staff."""
    return db.get_tickets(filter_type=filter)


@app.put("/api/kds/tickets/{ticket_id}/status", response_model=Ticket)
async def update_kds_ticket_status(ticket_id: str, payload: TicketStatusUpdateRequest):
    """Updates ticket status on KDS board (IN_PROGRESS -> READY -> SERVED)."""
    ticket = db.update_ticket_status(ticket_id, payload.status)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    return ticket


# ==============================================================================
# SAFE ACTIVITY-BASED LOUNGE
# ==============================================================================

@app.get("/api/lounge", response_model=List[LoungeLobby])
async def get_lounge(category: Optional[str] = Query("all")):
    """Lists safe activity lobbies with masked table numbers."""
    return db.get_lounge_lobbies(category=category)


@app.post("/api/lounge/wave", response_model=LoungeWaveResponse)
async def wave_to_buddy(payload: LoungeWaveRequest):
    """
    Sends a mutual wave to an activity lobby.
    On mutual wave: unmasks the table number and unlocks the 10% Buddy Perk promo code!
    """
    lobby = db.wave_to_lobby(payload.lobby_id, payload.guest_table)
    if not lobby:
        raise HTTPException(status_code=404, detail="Lounge lobby not found")

    return LoungeWaveResponse(
        success=True,
        matched=True,
        revealed_table=lobby.real_table,
        perk_unlocked=True,
        promo_code="BUDDY10",
        message=f"Mutual wave accepted with {lobby.host_name}! Table revealed ({lobby.real_table}). Enjoy 10% off your shared snack with code BUDDY10!",
    )


# ==============================================================================
# BARISTA AI WAITER & TABLE CONCIERGE
# ==============================================================================

@app.post("/api/ai/waiter", response_model=AiWaiterResponse)
async def chat_with_waiter(payload: AiWaiterRequest):
    """Gemini-powered table assistant with prompt injection guardrails."""
    reply, pairings = await query_gemini_waiter(
        message=payload.message,
        table_number=payload.table_number,
        cart_items=payload.cart_items,
    )
    return AiWaiterResponse(reply=reply, suggested_pairings=pairings)


@app.post("/api/table/action")
async def perform_table_action(payload: TableActionRequest):
    """Handles quick table requests (Call Staff, Water/Napkins, Change Seat)."""
    db.log_table_action(
        table_number=payload.table_number,
        action_type=payload.action_type,
        details=payload.details,
    )
    messages = {
        "water": f"Carafe of sparkling & still water heading to {payload.table_number}!",
        "staff": f"Floor barista notified. Walking over to {payload.table_number}!",
        "seat_change": f"Seat move request logged for {payload.table_number} ({payload.details}). Staff updated!",
    }
    return {
        "success": True,
        "message": messages.get(payload.action_type, f"Staff notified for {payload.table_number}."),
    }
