#!/usr/bin/env bash
# ==============================================================================
# infra/deploy.sh — Production Deployment Script for CafeBuddy AI 2.0
# Deploys to Google Cloud Run in asia-south1 with scale-to-zero compute.
# Hard budget limit: $5.00/mo | Least-Privilege SA | Non-root container
# ==============================================================================

set -euo pipefail

# Configuration parameters
PROJECT_ID="${PROJECT_ID:-encouraging-key-468205-j0}"
REGION="${REGION:-asia-south1}"
SERVICE_NAME="cafebuddy-service"
REPOSITORY_NAME="cafebuddy-repo"
IMAGE_TAG="latest"
IMAGE_URI="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPOSITORY_NAME}/${SERVICE_NAME}:${IMAGE_TAG}"
SERVICE_ACCOUNT_EMAIL="cafebuddy-sa@${PROJECT_ID}.iam.gserviceaccount.com"

echo "=== [1/4] Configuring gcloud Context ==="
# Set active project for deployment
gcloud config set project "${PROJECT_ID}"

# Set default region for deployment
gcloud config set compute/region "${REGION}"


echo "=== [2/4] Building and Pushing Container Image ==="
# In Cloud Shell, Docker is pre-installed. Using local Docker build + push bypasses Cloud Build API permission issues.
if command -v docker >/dev/null 2>&1; then
    echo "Building container directly via local Docker in Cloud Shell..."
    gcloud auth configure-docker "${REGION}-docker.pkg.dev" --quiet
    docker build -t "${IMAGE_URI}" .
    docker push "${IMAGE_URI}"
else
    echo "Docker not found, falling back to Cloud Build submit..."
    gcloud builds submit \
        --project="${PROJECT_ID}" \
        --tag="${IMAGE_URI}" \
        --timeout="10m" \
        .
fi


echo "=== [3/4] Deploying Service to Google Cloud Run ==="
# Deploy container to Cloud Run with scale-to-zero (min-instances: 0) and least-privilege SA
gcloud run deploy "${SERVICE_NAME}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --image="${IMAGE_URI}" \
    --platform="managed" \
    --service-account="${SERVICE_ACCOUNT_EMAIL}" \
    --min-instances=0 \
    --max-instances=2 \
    --memory="512Mi" \
    --cpu="1" \
    --timeout="60s" \
    --allow-unauthenticated \
    --set-env-vars="PROJECT_ID=${PROJECT_ID},USE_FIRESTORE=true,USE_VERTEX_AI=true" \
    --port=8080


echo "=== [4/4] Verifying Live Service & Smoke Testing ==="
# Retrieve public URL of the deployed Cloud Run service
SERVICE_URL=$(gcloud run services describe "${SERVICE_NAME}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --format="value(status.url)")

echo "Public Endpoint: ${SERVICE_URL}"

# 1. Test health check probe
echo "Testing /health..."
curl -fsS "${SERVICE_URL}/health" | grep -q '"status":"healthy"' && echo "✅ Health check passed!"

# 2. Test menu catalog retrieval
echo "Testing /api/menu..."
curl -fsS "${SERVICE_URL}/api/menu" | grep -q 'Cloud Oat Shaken Espresso' && echo "✅ Menu API passed!"

# 3. Test 10-second vibe check endpoint
echo "Testing /api/vibe-check..."
curl -fsS -X POST "${SERVICE_URL}/api/vibe-check" \
    -H "Content-Type: application/json" \
    -d '{"fuel":"caffeine","sweetness":50,"diet":"veg","allergies":[],"pace":"chilling"}' | grep -q 'recommendations' && echo "✅ Vibe Check API passed!"

echo "=============================================================================="
echo "🎉 DEPLOYMENT COMPLETE!"
echo "   Public URL:    ${SERVICE_URL}"
echo "   KDS Board:     ${SERVICE_URL}/#barista"
echo "   Lounge:        ${SERVICE_URL}/#lounge"
echo "   Service SA:    ${SERVICE_ACCOUNT_EMAIL}"
echo "   Compute Scale: 0 to 2 instances (Min: 0 for $5 budget limit)"
echo "=============================================================================="
