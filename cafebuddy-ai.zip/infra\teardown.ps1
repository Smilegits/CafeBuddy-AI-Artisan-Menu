# ==============================================================================
# infra/teardown.ps1 — PowerShell Safe Cleanup Script for CafeBuddy AI 2.0
# Cleans up all provisioned Google Cloud resources to prevent ongoing charges.
# Guardrail: Requires explicit human approval before any irreversible deletion.
# ==============================================================================

$PROJECT_ID = if ($env:PROJECT_ID) { $env:PROJECT_ID } else { "encouraging-key-468205-j0" }
$REGION = if ($env:REGION) { $env:REGION } else { "asia-south1" }
$SERVICE_NAME = "cafebuddy-service"
$REPOSITORY_NAME = "cafebuddy-repo"
$SECRET_NAME = "cafebuddy-session-secret"
$SERVICE_ACCOUNT_EMAIL = "cafebuddy-sa@${PROJECT_ID}.iam.gserviceaccount.com"

Write-Host "==============================================================================" -ForegroundColor Red
Write-Host "⚠️  WARNING: You are about to TEAR DOWN CafeBuddy AI Cloud Resources in:" -ForegroundColor Red
Write-Host "   Project: $PROJECT_ID" -ForegroundColor Red
Write-Host "   Region:  $REGION" -ForegroundColor Red
Write-Host "==============================================================================" -ForegroundColor Red

$confirmation = Read-Host "Are you absolutely sure you want to destroy these resources? Type 'DELETE' to proceed"

if ($confirmation -ne "DELETE") {
    Write-Host "Teardown aborted by user. No resources were modified or deleted." -ForegroundColor Yellow
    exit 0
}

Write-Host "=== [1/5] Deleting Cloud Run Service ===" -ForegroundColor Cyan
gcloud run services delete $SERVICE_NAME --project=$PROJECT_ID --region=$REGION --quiet 2>$null

Write-Host "=== [2/5] Deleting Artifact Registry Repository ===" -ForegroundColor Cyan
gcloud artifacts repositories delete $REPOSITORY_NAME --project=$PROJECT_ID --location=$REGION --quiet 2>$null

Write-Host "=== [3/5] Deleting Secret Manager Secret ===" -ForegroundColor Cyan
gcloud secrets delete $SECRET_NAME --project=$PROJECT_ID --quiet 2>$null

Write-Host "=== [4/5] Deleting Dedicated Service Account ===" -ForegroundColor Cyan
gcloud iam service-accounts delete $SERVICE_ACCOUNT_EMAIL --project=$PROJECT_ID --quiet 2>$null

Write-Host "==============================================================================" -ForegroundColor Green
Write-Host "✅ Teardown Complete! Project is in a clean, zero-cost state." -ForegroundColor Green
Write-Host "==============================================================================" -ForegroundColor Green
