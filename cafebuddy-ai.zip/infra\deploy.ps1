# ==============================================================================
# infra/deploy.ps1 — PowerShell Deployment Script for CafeBuddy AI 2.0
# Deploys to Google Cloud Run in asia-south1 with scale-to-zero compute.
# Hard budget limit: $5.00/mo | Least-Privilege SA | Non-root container
# ==============================================================================

$ErrorActionPreference = "Stop"

$PROJECT_ID = if ($env:PROJECT_ID) { $env:PROJECT_ID } else { "encouraging-key-468205-j0" }
$REGION = if ($env:REGION) { $env:REGION } else { "asia-south1" }
$SERVICE_NAME = "cafebuddy-service"
$REPOSITORY_NAME = "cafebuddy-repo"
$IMAGE_TAG = "latest"
$IMAGE_URI = "${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPOSITORY_NAME}/${SERVICE_NAME}:${IMAGE_TAG}"
$SERVICE_ACCOUNT_EMAIL = "cafebuddy-sa@${PROJECT_ID}.iam.gserviceaccount.com"

Write-Host "=== [1/4] Configuring gcloud Context ===" -ForegroundColor Cyan
# Set active project for deployment
gcloud config set project $PROJECT_ID
# Set default region for deployment
gcloud config set compute/region $REGION

Write-Host "=== [2/4] Building and Pushing Container Image via Cloud Build ===" -ForegroundColor Cyan
# Submit container build to Cloud Build and push directly to Artifact Registry
gcloud builds submit `
    --project=$PROJECT_ID `
    --tag=$IMAGE_URI `
    --timeout="10m" `
    .

Write-Host "=== [3/4] Deploying Service to Google Cloud Run ===" -ForegroundColor Cyan
# Deploy container to Cloud Run with scale-to-zero (min-instances: 0) and least-privilege SA
gcloud run deploy $SERVICE_NAME `
    --project=$PROJECT_ID `
    --region=$REGION `
    --image=$IMAGE_URI `
    --platform="managed" `
    --service-account=$SERVICE_ACCOUNT_EMAIL `
    --min-instances=0 `
    --max-instances=2 `
    --memory="512Mi" `
    --cpu="1" `
    --timeout="60s" `
    --allow-unauthenticated `
    --set-env-vars="PROJECT_ID=${PROJECT_ID},USE_FIRESTORE=true,USE_VERTEX_AI=true" `
    --port=8080

Write-Host "=== [4/4] Verifying Live Service & Smoke Testing ===" -ForegroundColor Cyan
# Retrieve public URL of the deployed Cloud Run service
$SERVICE_URL = gcloud run services describe $SERVICE_NAME `
    --project=$PROJECT_ID `
    --region=$REGION `
    --format="value(status.url)"

Write-Host "Public Endpoint: $SERVICE_URL" -ForegroundColor Green

Write-Host "Testing /health..."
$health = Invoke-RestMethod -Uri "$SERVICE_URL/health" -Method Get
if ($health.status -eq "healthy") {
    Write-Host "✅ Health check passed!" -ForegroundColor Green
}

Write-Host "Testing /api/menu..."
$menu = Invoke-RestMethod -Uri "$SERVICE_URL/api/menu" -Method Get
if ($menu.Count -ge 12) {
    Write-Host "✅ Menu API passed with $($menu.Count) items!" -ForegroundColor Green
}

Write-Host "==============================================================================" -ForegroundColor Green
Write-Host "🎉 DEPLOYMENT COMPLETE!" -ForegroundColor Green
Write-Host "   Public URL:    $SERVICE_URL" -ForegroundColor Green
Write-Host "   KDS Board:     $SERVICE_URL/#barista" -ForegroundColor Green
Write-Host "   Lounge:        $SERVICE_URL/#lounge" -ForegroundColor Green
Write-Host "   Service SA:    $SERVICE_ACCOUNT_EMAIL" -ForegroundColor Green
Write-Host "   Compute Scale: 0 to 2 instances (Min: 0 for $5 budget limit)" -ForegroundColor Green
Write-Host "==============================================================================" -ForegroundColor Green
