"""
Database repository for CafeBuddy AI 2.0.
Supports Google Cloud Firestore (Native mode) with in-memory fallback for local testing.
"""

import os
from datetime import datetime
from typing import List, Optional, Dict
from app.models import MenuItem, Ticket, LoungeLobby

# Realistic 12-item Artisan Harvest menu
MENU_ITEMS_SEED: List[Dict] = [
    {
        "id": "cloud-oat-shaken-espresso",
        "name": "Cloud Oat Shaken Espresso",
        "description": "Espresso whipped over brown sugar & micro-aerated oat milk.",
        "category": "coffee",
        "price": 6.50,
        "prep_time_minutes": 4,
        "caffeine": True,
        "sweetness_default": 50,
        "diet_tags": ["vegan", "dairy-free"],
        "allergens": [],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuBRfLAV-ZnMI4JTebE1MHn_NNV1KWk47IPwc-pDVe1KLfnTR_FjOqNvraX1-QARrUTYW-_2UF4dS3jbuxJ0uSlduOncwk4zWz7BUL7vIcPkLwuBpNH0UEeSf-HNYcHMA4C_1I7SHBHF0usKjFHCLWYLBU05i23DFyHab3U6Z5ahLTqVPDsUNYTY4nIbOQDVfNsGdRyLKYSuOp5Rc7FjfI-fKHao-uTeF7E29FExd6A",
        "available": True,
    },
    {
        "id": "kyoto-slow-drip-cold-brew",
        "name": "Kyoto Slow Drip Cold Brew",
        "description": "Ethiopian Yirgacheffe iced dripped over 14 hours.",
        "category": "coffee",
        "price": 5.75,
        "prep_time_minutes": 2,
        "caffeine": True,
        "sweetness_default": 0,
        "diet_tags": ["vegan", "dairy-free", "gluten-free"],
        "allergens": [],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuA1jecv0z7EDSCjiwVRHhZsC6TfkAYzn5qmCevUae32QVHzPv-IOxw1OEmkXIlOIkpY1RB19dwbbU1FWMdcC0bM96Ox1yGn29Q7GXNR1sJYcZo_6UEinqah9InNhPeSiXeVzjC_CDSGWV4fKJnRK4-cWtD881nJoFRApeHskXeyqXconQEq4a84E5bAP6kZDlMftw4uqi4Kn_UkIe1xfjAjHLBVW_R34PznAm1n0Eg",
        "available": True,
    },
    {
        "id": "ceremonial-matcha-honey",
        "name": "Ceremonial Matcha Honey",
        "description": "Uji ceremonial grade stone-milled green tea with clover honey.",
        "category": "coffee",
        "price": 6.25,
        "prep_time_minutes": 5,
        "caffeine": True,
        "sweetness_default": 50,
        "diet_tags": ["veg", "gluten-free"],
        "allergens": [],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuDgfRQ2Ry0OiMnGgLpV9Nky6vmciVnE7QehS7Lht51vMnid2CsrBi_tUjYqz3WSpig7zOGWPxnZA8iF8rR0Y9SKqdCkGXoy8u_vkzFWOYkVKa8ggaBN5FKfhHecRzpSBZAjwDWm5O6KsFblAjRKKtUeadNGGwgP6xTQITdqCI95Z5stnRkum9rPBcezuaor-ui5IH6l9g71yDGVc6Q7_oydeUxxTkTi8noVQSLYSU4",
        "available": True,
    },
    {
        "id": "pistachio-cardamom-latte",
        "name": "Pistachio Cardamom Latte",
        "description": "Real Bronte pistachio paste, organic whole milk, cardamom pod.",
        "category": "coffee",
        "price": 6.75,
        "prep_time_minutes": 6,
        "caffeine": True,
        "sweetness_default": 50,
        "diet_tags": ["veg"],
        "allergens": ["nuts", "dairy"],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuB9Hzg3mKLp163ophTUbsLxCmd6pVrYxv1ma_baxVhoiYWKnOonJ22kbELxlhc5Wjw1_f4sdgumQe5r83loxA86HxCBcFkkw-Iv9n9r0-o8eefKJEUelFUbyM8Cje63vN66xgHNHaLb91PjJ6F4Y6mEku-Ap-rEw2rHOEacOelPVaQC9jeW5jvoYBw1MKOAUWdRbLeFDCESoy1yJnN_3eLt2jXVywkLFp6Ic3gH3v8",
        "available": True,
    },
    {
        "id": "golden-turmeric-ginger",
        "name": "Golden Turmeric Ginger",
        "description": "Cold-pressed Hawaiian turmeric root, black pepper, oat milk.",
        "category": "coffee",
        "price": 5.50,
        "prep_time_minutes": 4,
        "caffeine": False,
        "sweetness_default": 50,
        "diet_tags": ["vegan", "dairy-free", "gluten-free"],
        "allergens": [],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuBZ5K83B9LSNOV8yXjPiLjdFFaXbp9fBtfUn4V7G0DjdR6wshLLf2BgCFNcgVxK5dX8e8eRxzMQ9b5iFFMZCzi6TTXpTKQC1NhbIYKwOETORgBtbH0td4t7yM8wx6NFtAjX3bJBIN-gEJ5dnYpXdowHmkMGfU2u5grmOc3-BhYIqfNC-IZi5Up9ouaAfP3czwoc703WhtgW24Si2D_wIxT4rrnodTfKD38FNWKCyps",
        "available": True,
    },
    {
        "id": "smoked-salmon-tartine",
        "name": "Smoked Salmon Tartine",
        "description": "Scottish salmon, pickled shallots, cured capers on seeded loaf.",
        "category": "savory",
        "price": 12.50,
        "prep_time_minutes": 11,
        "caffeine": False,
        "sweetness_default": 0,
        "diet_tags": ["non-veg"],
        "allergens": ["gluten"],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuDYrasYlqW2R7trLEh7_84KXGBYYiDbBTHFKdEx5Q3lvkGLarOK06N9ZgJSGekRjF3NYVWiPcnXCKqZdzfNAWxF8d18oXgHXGaJsot68-0ZpINEcseeO_mHXSiwlYb0aDyJnrc7LCCUY31irGjCw1Wno8aMeAz-OhoZRQjoGbQB2OGuKVblHYbNU2vuVaYyyxqVinReewkeuyw20zmWKawUxnlKNJ_spfiRZoPtDIM",
        "available": True,
    },
    {
        "id": "avocado-truffle-sourdough",
        "name": "Avocado Truffle Sourdough",
        "description": "Smashed avocado, white truffle oil, watermelon radish, seeds.",
        "category": "savory",
        "price": 10.50,
        "prep_time_minutes": 6,
        "caffeine": False,
        "sweetness_default": 0,
        "diet_tags": ["vegan", "dairy-free"],
        "allergens": [],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuCogxy6DuemRxPRy6ArD2ayq7RPqwoVhwh1z3jYzADRoBBqi6NWYqpFB8VMLincVYP0Tc7keqIqvHWcSDy_zHubZukzVvfbkL3SF-iuatSdnNM8Ckab7sTuyG99Vj0ELDeltjbD2qN9HAlED91jpkMbtpTcbA20KQwMhPPvisWQ0_hAcpQQa-G3YCaPPiqeoMj16gV2KJdsI6mpb780o_RU4h4k8ibFuQS5KdhqiiA",
        "available": True,
    },
    {
        "id": "brioche-fig-french-toast",
        "name": "Brioche Fig French Toast",
        "description": "Custard soaked brioche, brown sugar fig butter, pure maple syrup.",
        "category": "bakery",
        "price": 11.00,
        "prep_time_minutes": 14,
        "caffeine": False,
        "sweetness_default": 100,
        "diet_tags": ["veg"],
        "allergens": ["dairy", "gluten"],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuBQqGR9GY9ushG8VBCjYxOaXiqtf9HVfeNUXQJT31EtXB1weG0hEvo8kKbjSZDft0Ifx4Fmk-0gNW6F0cVyg-fC5N_5gfHI9MZkK9mu5uQGvrGAHKKxX3OZvFZZeJQELMmr0gIhbMgIO9Owfkv-P_euXJGF9k85VwQspb5C_UKF5aVU3wE8gWuxL1NRI53Gy8VxqFo-Xx4G6wtHJ1rt_WPDQ53bZLMqdpkkrYekeJ0",
        "available": True,
    },
    {
        "id": "blackberry-almond-croissant",
        "name": "Blackberry Almond Croissant",
        "description": "Twice-baked almond frangipane with homemade Oregon blackberry jam.",
        "category": "bakery",
        "price": 5.25,
        "prep_time_minutes": 3,
        "caffeine": False,
        "sweetness_default": 100,
        "diet_tags": ["veg"],
        "allergens": ["nuts", "dairy", "gluten"],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuBoN5yo25cUYwGwo6EpDOBaOt9HMdAbrnD13Y8POyZxskNCY0oHRrRyHi3J3blAZ-PeSdmK6I_nAvy_N_J0LQeIaqzglXJx7TYHVOAajuOl8qWI_Z3PmthwM-yjAFxHO61O3WDD5ZOmoIxPzVfYvW_si5I_LH9GimO3xlJf-bzlQrsLLEMHERgpySOSAttkyyObp8f4EkPQqXmYnymh4QtTykJBhRs8KoYzMAZLMt8",
        "available": True,
    },
    {
        "id": "miso-mushroom-melt",
        "name": "Miso Mushroom Melt",
        "description": "Roasted king oyster mushrooms, white miso glaze, fontina cheese on rye.",
        "category": "savory",
        "price": 11.75,
        "prep_time_minutes": 9,
        "caffeine": False,
        "sweetness_default": 0,
        "diet_tags": ["veg"],
        "allergens": ["dairy", "gluten"],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuD9OQVs9E-g7VwCVXmIfK0Nq0FYh6IH-nouUfSjLYkI4nHPRlXn6hEzFsw9vJGmMSgjIPbRa6rQubF_g8LLLkrLZAY2FKCZSm74E8DhORpd_fjb-muHpFGa19f59UfzK0bYnq79dlWh_X756Wz-OASN3C0MAV-qdGWm4pVokxUUhFoRV65fwioohKeHCGu1Pd2WyWrC45740JvRfEdDwFjFFHVeR7ONxaCEhOerSfw",
        "available": True,
    },
    {
        "id": "lemon-rosemary-shortbread",
        "name": "Lemon Rosemary Shortbread",
        "description": "Crisp Scottish butter biscuit infused with Meyer lemon & fresh rosemary.",
        "category": "bakery",
        "price": 3.75,
        "prep_time_minutes": 2,
        "caffeine": False,
        "sweetness_default": 50,
        "diet_tags": ["veg"],
        "allergens": ["dairy", "gluten"],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuC1P208o-K2Fw0tB44jK0tK0x12bK1f5tU_8h6m0N-f4sdgumQe5r83loxA86HxCBcFkkw-Iv9n9r0-o8eefKJEUelFUbyM8Cje63vN66xgHNHaLb91PjJ6F4Y6mEku-Ap-rEw2rHOEacOelPVaQC9jeW5jvoYBw1MKOAUWdRbLeFDCESoy1yJnN_3eLt2jXVywkLFp6Ic3gH3v8",
        "available": True,
    },
    {
        "id": "sparkling-cascara-tonic",
        "name": "Sparkling Cascara Tonic",
        "description": "Sun-dried coffee cherry tea effervescent with yuzu citrus peel.",
        "category": "coffee",
        "price": 5.25,
        "prep_time_minutes": 3,
        "caffeine": True,
        "sweetness_default": 50,
        "diet_tags": ["vegan", "dairy-free", "gluten-free"],
        "allergens": [],
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuDDhn6uK3fvoEvDqAe075kBcJaJO9Bvu2bPLEBhc0PEMkk1hXgzFAhAsVg57HV5ziPrbbsuRTnmDFLdgInLqPqdqFISNl0Xh0CQ68dtUiSSeiV1oT6pwtS9RjgA2QZVdAtzppizV0BvZi2XPxVX6YPP4nE4C3-fFwzq_7yUVO2dduocOWIny2b9k6idrGzyoMXQd47MwbluBj3sodloHe-5Ell0Q_82xD3yxS4ib_U",
        "available": True,
    },
]

# Seed Tickets for Live KDS
TICKETS_SEED: List[Dict] = [
    {
        "ticket_id": "TKT-104",
        "table_number": "Table #04",
        "guest_name": "Elena S.",
        "zone": "Sunlit Garden Atrium",
        "status": "IN_PROGRESS",
        "is_express": True,
        "has_allergy_alert": False,
        "allergy_flags": [],
        "sweetness_level": "50% Honey",
        "items": [
            {
                "item_id": "cloud-oat-shaken-espresso",
                "name": "Cloud Oat Shaken Espresso",
                "quantity": 1,
                "modifications": ["Decaf Oat", "50% Honey Sweetness"],
                "price": 6.50,
            },
            {
                "item_id": "avocado-truffle-sourdough",
                "name": "Avocado Truffle Sourdough",
                "quantity": 1,
                "modifications": ["Vegan", "Nut-Free"],
                "price": 10.50,
            },
        ],
        "subtotal": 17.00,
        "tip": 3.11,
        "total": 20.11,
        "payment_method": "Apple Pay Settled",
        "created_at": "2026-11-22T11:45:00Z",
        "elapsed_time": "3m 40s",
    },
    {
        "ticket_id": "TKT-102",
        "table_number": "Table #07",
        "guest_name": "James L.",
        "zone": "Window Counter",
        "status": "IN_PROGRESS",
        "is_express": False,
        "has_allergy_alert": True,
        "allergy_flags": ["TREE NUTS ALERT", "DAIRY FREE"],
        "sweetness_level": "Unsweetened",
        "items": [
            {
                "item_id": "pistachio-cardamom-latte",
                "name": "Pistachio Cardamom Latte (Swap to Oat)",
                "quantity": 1,
                "modifications": ["SEPARATE STEAM WAND", "OAT MILK ONLY"],
                "price": 6.75,
            }
        ],
        "subtotal": 6.75,
        "tip": 1.50,
        "total": 8.25,
        "payment_method": "Card Settled",
        "created_at": "2026-11-22T11:46:10Z",
        "elapsed_time": "2m 15s",
    },
    {
        "ticket_id": "TKT-105",
        "table_number": "Table #11",
        "guest_name": "Sarah M.",
        "zone": "Patio (Seat Move Approved)",
        "status": "IN_PROGRESS",
        "is_express": False,
        "has_allergy_alert": False,
        "allergy_flags": [],
        "sweetness_level": "Classic Sweet",
        "items": [
            {
                "item_id": "brioche-fig-french-toast",
                "name": "Brioche Fig French Toast",
                "quantity": 1,
                "modifications": ["Griddle In Progress"],
                "price": 11.00,
            }
        ],
        "subtotal": 11.00,
        "tip": 2.20,
        "total": 13.20,
        "payment_method": "Card Settled",
        "created_at": "2026-11-22T11:40:00Z",
        "elapsed_time": "8m 10s",
    },
]

# Seed Lounge Lobbies (Masked Table Numbers)
LOUNGE_LOBBIES_SEED: List[Dict] = [
    {
        "lobby_id": "lobby-dnd-01",
        "host_name": "Marcus K.",
        "masked_table": "Table #??",
        "real_table": "Table #08",
        "activity_category": "dnd",
        "activity_title": "One-Shot D&D 5e Campaign (Level 3)",
        "description": "Starting in 15 mins • Beginner friendly! Cozy dungeon crawl.",
        "players_needed": 2,
        "status": "OPEN",
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuCPItyvFJX1NASUVFkKt-prREEjZw5UtPJntxJyuyH3ua404RmC10KdWQCMc_p0xxNcNi8NCOE1xAxhu8nW14s4ec2ZxMlhq57h4rqfmPzjYE_VtXOtEpbHr578QrIqWkUp0mhpAL-9ideDImq-9HU1DbQhQ-LOn5aLJyNmCozKFirDXfyKHyrRHvV6ZT5a1F9f5id-rYWdCNchkN3u91OhCC0IkW70W92wlYFsqZI",
    },
    {
        "lobby_id": "lobby-chess-02",
        "host_name": "Liam T.",
        "masked_table": "Table #??",
        "real_table": "Table #03",
        "activity_category": "chess",
        "activity_title": "♟️ Speed Chess or Uno Duel",
        "description": "Casual 10-min blitz match with a latte.",
        "players_needed": 1,
        "status": "OPEN",
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuBRfLAV-ZnMI4JTebE1MHn_NNV1KWk47IPwc-pDVe1KLfnTR_FjOqNvraX1-QARrUTYW-_2UF4dS3jbuxJ0uSlduOncwk4zWz7BUL7vIcPkLwuBpNH0UEeSf-HNYcHMA4C_1I7SHBHF0usKjFHCLWYLBU05i23DFyHab3U6Z5ahLTqVPDsUNYTY4nIbOQDVfNsGdRyLKYSuOp5Rc7FjfI-fKHao-uTeF7E29FExd6A",
    },
    {
        "lobby_id": "lobby-cowork-03",
        "host_name": "Chloe V.",
        "masked_table": "Table #??",
        "real_table": "Table #14",
        "activity_category": "cowork",
        "activity_title": "💻 45-min Deep Focus Sprint",
        "description": "Silent co-working sprint, coffee break chat after.",
        "players_needed": 1,
        "status": "OPEN",
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuA1jecv0z7EDSCjiwVRHhZsC6TfkAYzn5qmCevUae32QVHzPv-IOxw1OEmkXIlOIkpY1RB19dwbbU1FWMdcC0bM96Ox1yGn29Q7GXNR1sJYcZo_6UEinqah9InNhPeSiXeVzjC_CDSGWV4fKJnRK4-cWtD881nJoFRApeHskXeyqXconQEq4a84E5bAP6kZDlMftw4uqi4Kn_UkIe1xfjAjHLBVW_R34PznAm1n0Eg",
    },
    {
        "lobby_id": "lobby-board-04",
        "host_name": "Julian R.",
        "masked_table": "Table #??",
        "real_table": "Table #09",
        "activity_category": "board",
        "activity_title": "🍰 Split a Dessert & Codenames",
        "description": "Down to split a French toast or croissant & play words.",
        "players_needed": 3,
        "status": "OPEN",
        "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuBQqGR9GY9ushG8VBCjYxOaXiqtf9HVfeNUXQJT31EtXB1weG0hEvo8kKbjSZDft0Ifx4Fmk-0gNW6F0cVyg-fC5N_5gfHI9MZkK9mu5uQGvrGAHKKxX3OZvFZZeJQELMmr0gIhbMgIO9Owfkv-P_euXJGF9k85VwQspb5C_UKF5aVU3wE8gWuxL1NRI53Gy8VxqFo-Xx4G6wtHJ1rt_WPDQ53bZLMqdpkkrYekeJ0",
    },
]


class DatabaseRepository:
    """Repository handling data access with Firestore support & in-memory fallbacks."""

    def __init__(self):
        self._use_firestore = os.getenv("USE_FIRESTORE", "false").lower() == "true"
        self._firestore_client = None

        if self._use_firestore:
            try:
                from google.cloud import firestore
                project_id = os.getenv("PROJECT_ID", "encouraging-key-468205-j0")
                self._firestore_client = firestore.Client(project=project_id)
            except Exception as e:
                print(f"[Warning] Cloud Firestore initialization failed: {e}. Falling back to memory.")
                self._use_firestore = False

        # In-memory storage structures
        self.menu: Dict[str, MenuItem] = {
            item["id"]: MenuItem(**item) for item in MENU_ITEMS_SEED
        }
        self.tickets: Dict[str, Ticket] = {
            t["ticket_id"]: Ticket(**t) for t in TICKETS_SEED
        }
        self.lobbies: Dict[str, LoungeLobby] = {
            l["lobby_id"]: LoungeLobby(**l) for l in LOUNGE_LOBBIES_SEED
        }
        self.table_service_log: List[Dict] = []

    def get_menu_items(
        self,
        category: Optional[str] = None,
        max_prep_minutes: Optional[int] = None,
        diet: Optional[str] = None,
        exclude_allergens: Optional[List[str]] = None,
    ) -> List[MenuItem]:
        items = list(self.menu.values())

        if category and category != "all":
            items = [i for i in items if i.category == category]

        if max_prep_minutes is not None:
            items = [i for i in items if i.prep_time_minutes <= max_prep_minutes]

        if diet and diet != "all":
            if diet == "vegan":
                items = [i for i in items if "vegan" in i.diet_tags]
            elif diet == "veg":
                items = [i for i in items if "veg" in i.diet_tags or "vegan" in i.diet_tags]
            elif diet == "non-veg":
                items = [i for i in items if "non-veg" in i.diet_tags]

        if exclude_allergens:
            safe_items = []
            for item in items:
                has_conflict = any(alg in item.allergens for alg in exclude_allergens)
                if not has_conflict:
                    safe_items.append(item)
            items = safe_items

        return items

    def get_menu_item(self, item_id: str) -> Optional[MenuItem]:
        return self.menu.get(item_id)

    def get_tickets(self, filter_type: str = "all") -> List[Ticket]:
        tickets = list(self.tickets.values())
        if filter_type == "express":
            tickets = [t for t in tickets if t.is_express]
        elif filter_type == "allergy":
            tickets = [t for t in tickets if t.has_allergy_alert]
        return sorted(tickets, key=lambda x: x.created_at, reverse=True)

    def create_ticket(self, ticket: Ticket) -> Ticket:
        self.tickets[ticket.ticket_id] = ticket
        return ticket

    def update_ticket_status(self, ticket_id: str, new_status: str) -> Optional[Ticket]:
        if ticket_id in self.tickets:
            self.tickets[ticket_id].status = new_status
            return self.tickets[ticket_id]
        return None

    def get_lounge_lobbies(self, category: Optional[str] = None) -> List[LoungeLobby]:
        lobbies = list(self.lobbies.values())
        if category and category != "all":
            lobbies = [l for l in lobbies if l.activity_category == category]
        return lobbies

    def wave_to_lobby(self, lobby_id: str, guest_table: str) -> Optional[LoungeLobby]:
        if lobby_id in self.lobbies:
            lobby = self.lobbies[lobby_id]
            # Mutual match simulation
            lobby.status = "MATCHED"
            lobby.masked_table = lobby.real_table  # reveal actual table
            lobby.perk_code = "BUDDY10"
            return lobby
        return None

    def log_table_action(self, table_number: str, action_type: str, details: Optional[str] = None):
        self.table_service_log.append({
            "table_number": table_number,
            "action_type": action_type,
            "details": details,
            "timestamp": datetime.utcnow().isoformat(),
        })


# Global singleton database instance
db = DatabaseRepository()
