# ==============================================================================
# infra/setup.ps1 — PowerShell Bootstrap Google Cloud Infrastructure for CafeBuddy AI
# Idempotent script for project: encouraging-key-468205-j0
# Hard budget limit: $5.00 USD/month | Least-Privilege IAM | Scales to Zero
# ==============================================================================

$ErrorActionPreference = "Stop"

$PROJECT_ID = if ($env:PROJECT_ID) { $env:PROJECT_ID } else { "encouraging-key-468205-j0" }
$REGION = if ($env:REGION) { $env:REGION } else { "asia-south1" }
$SERVICE_ACCOUNT_NAME = "cafebuddy-sa"
$SERVICE_ACCOUNT_EMAIL = "${SERVICE_ACCOUNT_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"
$REPOSITORY_NAME = "cafebuddy-repo"
$SECRET_NAME = "cafebuddy-session-secret"
$BUDGET_AMOUNT = "5.00"

Write-Host "=== [1/7] Setting Active Project & Region ===" -ForegroundColor Cyan
# Set the default Google Cloud project configuration
gcloud config set project $PROJECT_ID
# Set the default Google Cloud compute region configuration
gcloud config set compute/region $REGION

Write-Host "=== [2/7] Enabling Required Google Cloud APIs ===" -ForegroundColor Cyan
# Enable Cloud Run for serverless container execution
gcloud services enable run.googleapis.com
# Enable Firestore for real-time document storage
gcloud services enable firestore.googleapis.com
# Enable Vertex AI for low-cost Gemini Flash intelligence
gcloud services enable aiplatform.googleapis.com
# Enable Artifact Registry for storing production Docker container images
gcloud services enable artifactregistry.googleapis.com
# Enable Secret Manager for least-privilege runtime secret isolation
gcloud services enable secretmanager.googleapis.com
# Enable Cloud Logging for structured event and security logs
gcloud services enable logging.googleapis.com
# Enable Cloud Monitoring for latency and budget tracking
gcloud services enable monitoring.googleapis.com
# Enable Cloud Resource Manager for managing project IAM bindings
gcloud services enable cloudresourcemanager.googleapis.com
# Enable Billing Budgets API for the $5 hard budget alert notifications
gcloud services enable billingbudgets.googleapis.com

Write-Host "=== [3/7] Creating Least-Privilege Service Account ===" -ForegroundColor Cyan
$saCheck = gcloud iam service-accounts describe $SERVICE_ACCOUNT_EMAIL --project=$PROJECT_ID 2>$null
if (-not $saCheck) {
    # Create the dedicated least-privilege service account for CafeBuddy AI
    gcloud iam service-accounts create $SERVICE_ACCOUNT_NAME `
        --project=$PROJECT_ID `
        --display-name="CafeBuddy AI Cloud Run Service Account" `
        --description="Least-privilege identity for Cloud Run to access Firestore and Vertex AI"
    Write-Host "Service account created: $SERVICE_ACCOUNT_EMAIL" -ForegroundColor Green
} else {
    Write-Host "Service account $SERVICE_ACCOUNT_EMAIL already exists. Skipping creation." -ForegroundColor Yellow
}

Write-Host "=== [4/7] Binding Least-Privilege IAM Roles ===" -ForegroundColor Cyan
# Grant Firestore access for reading/writing menu items, tickets, and lounge state
gcloud projects add-iam-policy-binding $PROJECT_ID `
    --member="serviceAccount:$SERVICE_ACCOUNT_EMAIL" `
    --role="roles/datastore.user" `
    --condition=None

# Grant Vertex AI user role for invoking Gemini Flash models without API keys
gcloud projects add-iam-policy-binding $PROJECT_ID `
    --member="serviceAccount:$SERVICE_ACCOUNT_EMAIL" `
    --role="roles/aiplatform.user" `
    --condition=None

# Grant Secret Manager accessor to read isolated runtime configuration
gcloud projects add-iam-policy-binding $PROJECT_ID `
    --member="serviceAccount:$SERVICE_ACCOUNT_EMAIL" `
    --role="roles/secretmanager.secretAccessor" `
    --condition=None

# Grant Cloud Logging writer to emit structured operational and allergy alerts
gcloud projects add-iam-policy-binding $PROJECT_ID `
    --member="serviceAccount:$SERVICE_ACCOUNT_EMAIL" `
    --role="roles/logging.logWriter" `
    --condition=None

Write-Host "=== [5/7] Provisioning Storage & Artifact Registry ===" -ForegroundColor Cyan
$repoCheck = gcloud artifacts repositories describe $REPOSITORY_NAME --location=$REGION --project=$PROJECT_ID 2>$null
if (-not $repoCheck) {
    # Create Docker repository in Artifact Registry with standard pricing
    gcloud artifacts repositories create $REPOSITORY_NAME `
        --project=$PROJECT_ID `
        --location=$REGION `
        --repository-format=docker `
        --description="Docker container repository for CafeBuddy AI"
    Write-Host "Artifact Registry repository created: $REPOSITORY_NAME" -ForegroundColor Green
} else {
    Write-Host "Artifact Registry repository $REPOSITORY_NAME already exists." -ForegroundColor Yellow
}

$fsCheck = gcloud firestore databases describe --project=$PROJECT_ID 2>$null
if (-not $fsCheck) {
    # Create default Firestore database in Native mode within the designated region
    gcloud firestore databases create `
        --project=$PROJECT_ID `
        --location=$REGION `
        --type=firestore-native
    Write-Host "Cloud Firestore database created in $REGION (Native mode)." -ForegroundColor Green
} else {
    Write-Host "Cloud Firestore database already exists." -ForegroundColor Yellow
}

Write-Host "=== [6/7] Creating Secret in Secret Manager ===" -ForegroundColor Cyan
$secCheck = gcloud secrets describe $SECRET_NAME --project=$PROJECT_ID 2>$null
if (-not $secCheck) {
    # Create secret container in Secret Manager for session encryption
    gcloud secrets create $SECRET_NAME --project=$PROJECT_ID --replication-policy="automatic"
    $randBytes = -join ((1..32) | ForEach-Object { "{0:x2}" -f (Get-Random -Max 256) })
    $randBytes | gcloud secrets versions add $SECRET_NAME --project=$PROJECT_ID --data-file=-
    Write-Host "Secret $SECRET_NAME created and populated." -ForegroundColor Green
} else {
    Write-Host "Secret $SECRET_NAME already exists." -ForegroundColor Yellow
}

Write-Host "=== [7/7] Configuring $5.00 Monthly Budget Alert ===" -ForegroundColor Cyan
$billingAccount = gcloud billing projects describe $PROJECT_ID --format="value(billingAccountName)" 2>$null
if ($billingAccount) {
    $billingId = $billingAccount.Split('/')[-1]
    Write-Host "Found linked Billing Account: $billingId"
    $existingBudget = gcloud billing budgets list --billing-account=$billingId --filter="displayName:cafebuddy-5usd-budget" --format="value(name)" 2>$null
    if (-not $existingBudget) {
        # Create budget alert with hard $5.00 limit and thresholds at 50% ($2.50), 90% ($4.50), and 100% ($5.00)
        gcloud billing budgets create `
            --billing-account=$billingId `
            --display-name="cafebuddy-5usd-budget" `
            --budget-amount="${BUDGET_AMOUNT}USD" `
            --filter-projects="projects/${PROJECT_ID}" `
            --threshold-rule="percent=0.5,basis=current-spend" `
            --threshold-rule="percent=0.9,basis=current-spend" `
            --threshold-rule="percent=1.0,basis=current-spend"
        Write-Host "Budget alert created with thresholds at 50%, 90%, 100%." -ForegroundColor Green
    } else {
        Write-Host "Budget alert already exists. Skipping creation." -ForegroundColor Yellow
    }
} else {
    Write-Host "Notice: Linked billing account not directly queryable via current credentials." -ForegroundColor Yellow
}

Write-Host "==============================================================================" -ForegroundColor Green
Write-Host " Infrastructure Bootstrap Complete for Project: $PROJECT_ID" -ForegroundColor Green
Write-Host "==============================================================================" -ForegroundColor Green
