# CafeBuddy AI 2.0 — Smart Dining & Kitchen Expediter

> **A 10-second smart host for café guests, privacy-first activity lounge, and zero-chaos live kitchen ticket system built on Google Cloud.**

---

## ☕ Overview
**CafeBuddy AI 2.0** bridges customer front-of-house table experience with back-of-house kitchen operations without survey fatigue or awkward social pressure:
1. **10-Second "3-Tap Vibe Check":** Rapid ordering based on Fuel (Caffeine/Sweet/Meal), Dietary/Allergy guardrails, and Kitchen Pace (Chilling vs. Express ≤7m).
2. **Returning Guest 1-Tap Reorder:** Elena's Usual auto-fill based on past visit preferences.
3. **Smart Kitchen-Protected Express Mode:** Automatically excludes >7 min items when guests are in a rush.
4. **Safe Activity-Based Lounge:** Privacy-masked table numbers (`Table #??`) until mutual wave acceptance, prompt tags (Chess, Uno, Co-working, Split Dessert), and 10% Buddy combo discount.
5. **Live Barista & Kitchen KDS Board:** Real-time ticket management with high-contrast allergy badges, sweetness ratings, and prep timers.
6. **Floating Barista AI Waiter:** Gemini-powered table assistant for dish pairing, allergen clarifications, and bill queries.

---

## 🏛️ Target Cloud Architecture (Google Cloud)
- **Compute:** Google Cloud Run (Fully managed, containerized FastAPI + Static Web UI, auto-scales 0 to N).
- **AI Intelligence:** Gemini 1.5/2.5 Flash via Vertex AI / Google GenAI SDK (ultra-low latency, cost-effective).
- **Data Persistence:** Cloud Firestore (Native mode, real-time ticket stream, table states, lounge sessions).
- **Security & IAM:** Dedicated Least-privilege Service Account `cafebuddy-sa`, Google Secret Manager.
- **Observability:** Cloud Logging & Google Cloud Monitoring Budget Alert ($5 hard cap).

---

## 📂 Project Structure
```
cafebuddy-ai/
├── README.md               # Complete architecture, setup, testing, and operational runbook
├── DECISIONS.md            # Architecture Decision Records (ADRs) and trade-offs
├── cloudbuild.yaml         # Automated CI/CD pipeline (Test -> Build -> Push -> Deploy)
├── Dockerfile              # Multi-stage production container for Cloud Run
├── requirements.txt        # Python package dependencies
├── infra/                  # Infrastructure as code (gcloud bootstrap, alerts, and teardown)
│   ├── setup.sh            # Phase 2 Idempotent cloud bootstrap script (Bash)
│   ├── setup.ps1           # Phase 2 Idempotent cloud bootstrap script (PowerShell)
│   ├── deploy.sh           # Phase 5 Production deployment script (Bash)
│   ├── deploy.ps1          # Phase 5 Production deployment script (PowerShell)
│   ├── alerts.sh           # Phase 6 Cloud Monitoring alert policies & logging
│   ├── teardown.sh         # Phase 6 Safe resource cleanup script (Bash)
│   └── teardown.ps1        # Phase 6 Safe resource cleanup script (PowerShell)
├── app/                    # Application source code
│   ├── static/             # Frontend assets & Artisan Harvest UI templates
│   │   └── index.html      # Mobile-first single screen + KDS board + AI drawer
│   ├── main.py             # FastAPI backend with Gemini & Firestore integration
│   ├── database.py         # Cloud Firestore & thread-safe local fallback repository
│   ├── ai_waiter.py        # Gemini Flash AI waiter with prompt-injection guardrails
│   └── models.py           # Pydantic schemas (Menu, Order, Ticket, Lounge)
└── tests/                  # Automated test suite and Gemini eval set
    ├── test_api.py         # 14 API integration and unit tests (100% pass)
    └── test_eval_gemini.py # 15-case Gemini safety & injection eval set (100% pass)
```

---

## 💻 Local Quickstart

```bash
cd "C:\Users\SHREE RAM\.gemini\antigravity\scratch\cafebuddy-ai"

# Install requirements
pip install -r requirements.txt

# Run the local server
uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload
```
Open **`http://localhost:8080`** in your browser.

---

## 🧪 Automated Testing & Evaluation

```bash
# Run unit & API integration tests (14/14 pass)
python -m pytest tests/test_api.py -v

# Run the 15-case Gemini safety, prompt-injection & allergen eval suite (15/15 pass)
python tests/test_eval_gemini.py
```

---

## 🚀 Google Cloud Deployment (Cloud Run)

```bash
export PROJECT_ID="encouraging-key-468205-j0"
export REGION="asia-south1"

# 1. Bootstrap cloud infrastructure
chmod +x infra/setup.sh
./infra/setup.sh

# 2. Deploy application revision
chmod +x infra/deploy.sh
./infra/deploy.sh
```

---

## ⚙️ Operations, Observability & CI/CD (Phase 6)

### 1. Automated CI/CD (`cloudbuild.yaml`)
Submitting a build triggers the 4-stage pipeline:
1. **Automated Testing:** Runs `pytest` and `test_eval_gemini.py`. If any test fails, deployment is aborted immediately.
2. **Container Build:** Builds multi-stage Docker image with Git commit SHA and `latest` tags.
3. **Artifact Registry Push:** Securely uploads image to `asia-south1-docker.pkg.dev`.
4. **Cloud Run Rollout:** Deploys container with `--min-instances 0` to preserve the $5 budget.

To trigger manually:
```bash
gcloud builds submit --config=cloudbuild.yaml .
```

### 2. Operational Logging & Cloud Monitoring
To configure error alerts and logging queries:
```bash
chmod +x infra/alerts.sh
./infra/alerts.sh
```

Useful Cloud Logging filters:
* **Allergen Alerts:** `resource.type="cloud_run_revision" AND jsonPayload.message=~"ALLERGEN"`
* **Adversarial / Injection Attempts:** `resource.type="cloud_run_revision" AND jsonPayload.message=~"INJECTION"`
* **Cloud Run 5xx Errors:** `resource.type="cloud_run_revision" AND httpRequest.status>=500`

---

## 🧹 Resource Teardown (`infra/teardown.sh`)
To clean up all provisioned resources and prevent future cloud spend:
```bash
chmod +x infra/teardown.sh
./infra/teardown.sh
```
*Requires typing `DELETE` for human approval before removing any resources.*

---

## 🚀 Phases Roadmap
- [x] **Phase 1: Design & Architecture** (Specification, data models, UI alignment, cost analysis)
- [x] **Phase 2: Bootstrap Infra** (`infra/setup.sh` with gcloud, budget alerts, least-privilege IAM)
- [x] **Phase 3: Build Locally** (FastAPI backend + Artisan Harvest UI integration + Gemini AI waiter)
- [x] **Phase 4: Test & Eval** (14 automated API tests + 15-case Gemini safety/injection eval set)
- [x] **Phase 5: Deploy to Cloud Run** (Live deployment scripts, exact gcloud commands, smoke tests)
- [x] **Phase 6: Operate & CI/CD** (Cloud Build, Cloud Monitoring alerts, and teardown runbook)
