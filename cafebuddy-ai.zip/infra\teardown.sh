#!/usr/bin/env bash
# ==============================================================================
# infra/teardown.sh — Safe Idempotent Cleanup Script for CafeBuddy AI 2.0
# Cleans up all provisioned Google Cloud resources to prevent ongoing charges.
# Guardrail: Requires explicit human approval before any irreversible deletion.
# ==============================================================================

set -euo pipefail

PROJECT_ID="${PROJECT_ID:-encouraging-key-468205-j0}"
REGION="${REGION:-asia-south1}"
SERVICE_NAME="cafebuddy-service"
REPOSITORY_NAME="cafebuddy-repo"
SECRET_NAME="cafebuddy-session-secret"
SERVICE_ACCOUNT_EMAIL="cafebuddy-sa@${PROJECT_ID}.iam.gserviceaccount.com"

echo "=============================================================================="
echo "⚠️  WARNING: You are about to TEAR DOWN CafeBuddy AI Cloud Resources in:"
echo "   Project: ${PROJECT_ID}"
echo "   Region:  ${REGION}"
echo "=============================================================================="
echo "Resources targeted for deletion:"
echo "  - Cloud Run Service:       ${SERVICE_NAME}"
echo "  - Artifact Registry Repo:   ${REPOSITORY_NAME}"
echo "  - Secret Manager Secret:   ${SECRET_NAME}"
echo "  - Service Account & IAM:   ${SERVICE_ACCOUNT_EMAIL}"
echo "  - Monitoring Policies & Channels"
echo "=============================================================================="

# Human approval guardrail
read -rp "Are you absolutely sure you want to destroy these resources? Type 'DELETE' to proceed: " CONFIRMATION

if [[ "${CONFIRMATION}" != "DELETE" ]]; then
    echo "Teardown aborted by user. No resources were modified or deleted."
    exit 0
fi

echo "Proceeding with resource teardown..."

echo "=== [1/6] Deleting Cloud Run Service ==="
# Delete Cloud Run service if it exists
if gcloud run services describe "${SERVICE_NAME}" --region="${REGION}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
    gcloud run services delete "${SERVICE_NAME}" \
        --project="${PROJECT_ID}" \
        --region="${REGION}" \
        --quiet
    echo "Cloud Run service ${SERVICE_NAME} deleted."
else
    echo "Cloud Run service ${SERVICE_NAME} not found. Skipping."
fi


echo "=== [2/6] Deleting Artifact Registry Repository ==="
# Delete Docker images and repository in Artifact Registry
if gcloud artifacts repositories describe "${REPOSITORY_NAME}" --location="${REGION}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
    gcloud artifacts repositories delete "${REPOSITORY_NAME}" \
        --project="${PROJECT_ID}" \
        --location="${REGION}" \
        --quiet
    echo "Artifact Registry repository ${REPOSITORY_NAME} deleted."
else
    echo "Artifact Registry repository ${REPOSITORY_NAME} not found. Skipping."
fi


echo "=== [3/6] Deleting Secret Manager Secret ==="
# Delete session secret container and its versions
if gcloud secrets describe "${SECRET_NAME}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
    gcloud secrets delete "${SECRET_NAME}" \
        --project="${PROJECT_ID}" \
        --quiet
    echo "Secret ${SECRET_NAME} deleted."
else
    echo "Secret ${SECRET_NAME} not found. Skipping."
fi


echo "=== [4/6] Removing IAM Role Bindings ==="
# Remove least-privilege IAM bindings
ROLES=(
    "roles/datastore.user"
    "roles/aiplatform.user"
    "roles/secretmanager.secretAccessor"
    "roles/logging.logWriter"
)

for ROLE in "${ROLES[@]}"; do
    gcloud projects remove-iam-policy-binding "${PROJECT_ID}" \
        --member="serviceAccount:${SERVICE_ACCOUNT_EMAIL}" \
        --role="${ROLE}" \
        --condition=None --quiet >/dev/null 2>&1 || true
    echo "Removed IAM binding: ${ROLE}"
done


echo "=== [5/6] Deleting Dedicated Service Account ==="
# Delete the dedicated service account
if gcloud iam service-accounts describe "${SERVICE_ACCOUNT_EMAIL}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
    gcloud iam service-accounts delete "${SERVICE_ACCOUNT_EMAIL}" \
        --project="${PROJECT_ID}" \
        --quiet
    echo "Service Account ${SERVICE_ACCOUNT_EMAIL} deleted."
else
    echo "Service Account ${SERVICE_ACCOUNT_EMAIL} not found. Skipping."
fi


echo "=== [6/6] Cleaning Up Alert Policies ==="
# Delete monitoring policies associated with CafeBuddy
POLICIES=$(gcloud monitoring policies list --project="${PROJECT_ID}" --filter="displayName:CafeBuddy" --format="value(name)" 2>/dev/null || true)
if [[ -n "${POLICIES}" ]]; then
    for POLICY in ${POLICIES}; do
        gcloud monitoring policies delete "${POLICY}" --quiet 2>/dev/null || true
        echo "Deleted monitoring policy: ${POLICY}"
    done
fi

echo "=============================================================================="
echo "✅ Teardown Complete! All active compute, storage, and IAM resources cleaned."
echo "   Your project is returned to a clean, zero-cost state."
echo "=============================================================================="
