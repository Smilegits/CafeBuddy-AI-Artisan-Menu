"""
Data models and schemas for CafeBuddy AI 2.0.
Strict Pydantic schemas validating all inputs and outputs.
"""

from typing import List, Optional
from pydantic import BaseModel, Field


class MenuItem(BaseModel):
    id: str
    name: str
    description: str
    category: str  # "coffee", "bakery", "savory"
    price: float
    prep_time_minutes: int
    caffeine: bool = False
    sweetness_default: int = 0  # 0, 50, 100
    diet_tags: List[str] = Field(default_factory=list)  # ["veg", "vegan", "gluten-free", "dairy-free"]
    allergens: List[str] = Field(default_factory=list)  # ["nuts", "dairy", "gluten"]
    image_url: str
    available: bool = True


class VibeCheckRequest(BaseModel):
    fuel: str = Field(..., description="Caffeine, sweet, or savory")
    sweetness: int = Field(50, ge=0, le=100, description="0, 50, or 100 percent")
    diet: str = Field("all", description="all, veg, non-veg, vegan")
    allergies: List[str] = Field(default_factory=list, description="nuts, dairy, gluten, caffeine_sens")
    pace: str = Field("chilling", description="chilling or rush")


class VibeCheckRecommendation(BaseModel):
    item: MenuItem
    match_score: int
    reason: str
    is_express: bool
    has_allergy_warning: bool


class VibeCheckResponse(BaseModel):
    recommendations: List[VibeCheckRecommendation]
    express_mode_active: bool
    filtered_out_due_to_rush: int


class OrderItem(BaseModel):
    item_id: str
    name: str
    quantity: int = Field(1, ge=1)
    modifications: List[str] = Field(default_factory=list)
    price: float


class OrderCreateRequest(BaseModel):
    table_number: str = "Table #04"
    guest_name: str = "Elena S."
    zone: str = "Sunlit Garden Atrium"
    items: List[OrderItem]
    pace: str = "chilling"
    tip: float = 0.0
    allergies_noted: List[str] = Field(default_factory=list)
    sweetness_noted: str = "50% Honey"


class Ticket(BaseModel):
    ticket_id: str
    table_number: str
    guest_name: str
    zone: str
    status: str = "IN_PROGRESS"  # "NEW", "IN_PROGRESS", "READY", "SERVED"
    is_express: bool = False
    has_allergy_alert: bool = False
    allergy_flags: List[str] = Field(default_factory=list)
    sweetness_level: str = "50% Honey"
    items: List[OrderItem]
    subtotal: float
    tip: float
    total: float
    payment_method: str = "Apple Pay Settled"
    created_at: str
    elapsed_time: str = "0m 30s"


class TicketStatusUpdateRequest(BaseModel):
    status: str = Field(..., description="IN_PROGRESS, READY, or SERVED")


class LoungeLobby(BaseModel):
    lobby_id: str
    host_name: str
    masked_table: str = "Table #??"
    real_table: str
    activity_category: str  # "dnd", "chess", "board", "cowork"
    activity_title: str
    description: str
    players_needed: int = 1
    status: str = "OPEN"  # "OPEN", "MATCHED"
    perk_code: Optional[str] = None
    image_url: str


class LoungeWaveRequest(BaseModel):
    lobby_id: str
    guest_table: str = "Table #04"
    message: Optional[str] = "Waving to connect!"


class LoungeWaveResponse(BaseModel):
    success: bool
    matched: bool
    revealed_table: Optional[str] = None
    perk_unlocked: bool = True
    promo_code: str = "BUDDY10"
    message: str


class AiWaiterRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=500)
    table_number: str = "Table #04"
    cart_items: List[str] = Field(default_factory=list)


class AiWaiterResponse(BaseModel):
    reply: str
    suggested_pairings: List[str] = Field(default_factory=list)


class TableActionRequest(BaseModel):
    table_number: str = "Table #04"
    action_type: str = Field(..., description="water, staff, seat_change")
    details: Optional[str] = None
