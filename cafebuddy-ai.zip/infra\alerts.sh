#!/usr/bin/env bash
# ==============================================================================
# infra/alerts.sh — Cloud Monitoring & Alert Policies for CafeBuddy AI 2.0
# Sets up budget notifications, error rate alerts, and latency thresholds.
# Hard budget limit: $5.00/month
# ==============================================================================

set -euo pipefail

PROJECT_ID="${PROJECT_ID:-encouraging-key-468205-j0}"
REGION="${REGION:-asia-south1}"
SERVICE_NAME="cafebuddy-service"
NOTIFICATION_CHANNEL_EMAIL="${NOTIFICATION_CHANNEL_EMAIL:-admin@example.com}"

echo "=== [1/3] Creating Notification Channel ==="
# Check if email notification channel already exists
CHANNEL_ID=$(gcloud monitoring channels list \
    --project="${PROJECT_ID}" \
    --filter="type=email AND labels.email_address='${NOTIFICATION_CHANNEL_EMAIL}'" \
    --format="value(name)" 2>/dev/null || true)

if [[ -z "${CHANNEL_ID}" ]]; then
    # Create email notification channel for operational alerts
    CHANNEL_ID=$(gcloud monitoring channels create \
        --project="${PROJECT_ID}" \
        --display-name="CafeBuddy Admin Alerts" \
        --type="email" \
        --channel-labels="email_address=${NOTIFICATION_CHANNEL_EMAIL}" \
        --format="value(name)")
    echo "Notification channel created: ${CHANNEL_ID}"
else
    echo "Notification channel already exists: ${CHANNEL_ID}"
fi


echo "=== [2/3] Creating Cloud Run 5xx Error Alert Policy ==="
# Alert policy for Cloud Run HTTP 5xx errors exceeding 5% of traffic over a 5-minute window
cat <<EOF > /tmp/error-rate-policy.json
{
  "displayName": "CafeBuddy Cloud Run High 5xx Error Rate",
  "combiner": "OR",
  "conditions": [
    {
      "displayName": "HTTP 5xx Error Rate > 5%",
      "conditionThreshold": {
        "filter": "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"${SERVICE_NAME}\" AND metric.type = \"run.googleapis.com/request_count\" AND metric.labels.response_code_class = \"5xx\"",
        "aggregations": [
          {
            "alignmentPeriod": "300s",
            "perSeriesAligner": "ALIGN_RATE"
          }
        ],
        "comparison": "COMPARISON_GT",
        "thresholdValue": 0.05,
        "duration": "60s",
        "trigger": {
          "count": 1
        }
      }
    }
  ],
  "notificationChannels": [
    "${CHANNEL_ID}"
  ]
}
EOF

# Create or update monitoring alert policy for Cloud Run errors
gcloud monitoring policies create \
    --project="${PROJECT_ID}" \
    --policy-from-file="/tmp/error-rate-policy.json" || true
rm -f /tmp/error-rate-policy.json


echo "=== [3/3] Operational Logging Query Filters ==="
echo "To view structured application logs in Cloud Logging:"
echo "1. Allergen Guardrail Alert Logs:"
echo "   gcloud logging read 'resource.type=\"cloud_run_revision\" AND jsonPayload.message=~\"ALLERGEN\"' --limit=20"
echo "2. Gemini Prompt Injection Attempts:"
echo "   gcloud logging read 'resource.type=\"cloud_run_revision\" AND jsonPayload.message=~\"INJECTION\"' --limit=20"
echo "3. Budget Alerts & Incurred Costs:"
echo "   gcloud logging read 'resource.type=\"budget\"' --limit=10"

echo "=============================================================================="
echo "✅ Operational Alert Policies & Logging Configured!"
echo "=============================================================================="
